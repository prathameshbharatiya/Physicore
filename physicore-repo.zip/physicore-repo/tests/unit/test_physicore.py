"""
PhysiCore Unit Tests
====================
Tests the theoretical properties from the paper:
  - Theorem 1: State boundedness under bounded residuals
  - Theorem 2: Parameter convergence under projected gradient descent
  - Proposition 1: Uncertainty penalty reduces high-variance trajectory selection

Run: python -m pytest tests/unit/test_physicore.py -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

import numpy as np
import pytest
from physicore import PhysiCore, PhysiCoreConfig, PhysicsLayer, ResidualEnsemble, OnlineSystemID


# ── Test fixtures ──────────────────────────────────────────────────────────────

def simple_dynamics(state, action, params):
    """Linear test dynamics: ẋ = Ax + Bu"""
    A = np.eye(4) * 0.99      # Stable linear system
    B = np.eye(4, 2) * 0.1
    return A @ state + B @ action


@pytest.fixture
def basic_cfg():
    return PhysiCoreConfig(state_dim=4, action_dim=2, control_hz=60.0,
                           param_bounds={"mass": (0.1, 10.0), "friction": (0.0, 1.0)})


@pytest.fixture
def basic_engine(basic_cfg):
    Q = np.eye(4) * 5.0
    R = np.eye(2) * 0.5
    params = {"mass": 1.0, "friction": 0.2}
    return PhysiCore(basic_cfg, simple_dynamics, params, Q, R)


# ── Physics Layer Tests ────────────────────────────────────────────────────────

class TestPhysicsLayer:
    def test_rk4_conserves_energy_linear(self):
        """RK4 should be more accurate than Euler for same step size."""
        def linear_dyn(s, a, p): return -0.1 * s   # stable decay

        phys = PhysicsLayer(linear_dyn, {"mass": 1.0})
        state = np.array([1.0])
        action = np.array([0.0])
        dt = 0.1

        rk4_next = phys.step(state, action, dt)
        euler_next = state + dt * linear_dyn(state, action, {"mass": 1.0})
        exact = state * np.exp(-0.1 * dt)   # analytical solution

        rk4_err   = abs(rk4_next[0] - exact[0])
        euler_err = abs(euler_next[0] - exact[0])
        assert rk4_err < euler_err, "RK4 must be more accurate than Euler"

    def test_rollout_shape(self):
        phys = PhysicsLayer(simple_dynamics, {"mass": 1.0, "friction": 0.2})
        state = np.zeros(4)
        actions = np.random.randn(10, 2)
        traj = phys.rollout(state, actions, dt=1/60)
        assert traj.shape == (11, 4), f"Expected (11,4) got {traj.shape}"

    def test_param_update(self):
        phys = PhysicsLayer(simple_dynamics, {"mass": 1.0})
        phys.update_params({"mass": 2.5})
        assert phys.params["mass"] == 2.5


# ── Residual Ensemble Tests ────────────────────────────────────────────────────

class TestResidualEnsemble:
    def test_ensemble_shapes(self, basic_cfg):
        ens = ResidualEnsemble(basic_cfg)
        state  = np.random.randn(4)
        action = np.random.randn(2)
        residual, uncertainty = ens.predict(state, action)
        assert residual.shape == (4,),  f"Residual shape {residual.shape}"
        assert isinstance(uncertainty, float)

    def test_uncertainty_is_non_negative(self, basic_cfg):
        ens = ResidualEnsemble(basic_cfg)
        for _ in range(20):
            s = np.random.randn(4)
            a = np.random.randn(2)
            _, unc = ens.predict(s, a)
            assert unc >= 0, f"Uncertainty must be ≥ 0, got {unc}"

    def test_learning_reduces_residual_error(self, basic_cfg):
        """After training on consistent data, residual error should decrease."""
        ens    = ResidualEnsemble(basic_cfg)
        state  = np.ones(4) * 0.5
        action = np.ones(2) * 0.1
        target = np.ones(4) * 0.05   # true residual

        # Collect 200 experience points
        for _ in range(200):
            noise = np.random.randn(4) * 0.01
            ens.add_experience(state, action,
                               sim_pred=state + 0.0,
                               real_next=state + target + noise)
        ens.update_all()

        pred, _ = ens.predict(state, action)
        error = np.linalg.norm(pred - target)
        # Should be better than random (random baseline ~sqrt(4) * 0.5 ≈ 1.0)
        assert error < 0.5, f"Ensemble should learn residual, error={error:.3f}"


# ── Online System ID Tests — Theorem 2 ────────────────────────────────────────

class TestOnlineSystemID:
    def test_projection_stays_in_bounds(self, basic_cfg):
        """Theorem 2 / Assumption A5: params must stay in Θ at all times."""
        params = {"mass": 1.0, "friction": 0.2}
        sysid  = OnlineSystemID(basic_cfg, params)
        phys   = PhysicsLayer(simple_dynamics, params)

        for _ in range(500):
            s  = np.random.randn(4)
            a  = np.random.randn(2)
            ns = s + np.random.randn(4) * 2.0   # random real observation
            sysid.update(s, a, ns, phys)

        for name, (lo, hi) in basic_cfg.param_bounds.items():
            if name in sysid.params:
                val = sysid.params[name]
                assert lo <= val <= hi, \
                    f"Param '{name}' = {val} outside bounds [{lo}, {hi}]"

    def test_convergence_toward_true_param(self, basic_cfg):
        """System ID should move mass estimate toward true value over time."""
        true_mass = 3.0
        init_mass = 1.0
        params = {"mass": init_mass, "friction": 0.1}

        def dyn_with_mass(s, a, p):
            return -p["mass"] * s[:len(a)] * 0.01 + a * 0.1

        cfg = PhysiCoreConfig(state_dim=2, action_dim=2, control_hz=60.0,
                               param_bounds={"mass": (0.1, 10.0), "friction": (0.0, 1.0)},
                               sysid_update_every=1)
        sysid = OnlineSystemID(cfg, params)
        phys  = PhysicsLayer(dyn_with_mass, params)

        initial_dist = abs(sysid.params["mass"] - true_mass)
        for _ in range(300):
            s  = np.random.randn(2) * 0.5
            a  = np.random.randn(2) * 0.3
            ns = s + (-true_mass * s * 0.01 + a * 0.1) / 60.0
            sysid.update(s, a, ns, phys)

        final_dist = abs(sysid.params["mass"] - true_mass)
        # Mass estimate should move toward true value (not necessarily there in 300 steps)
        assert final_dist <= initial_dist + 0.1, \
            f"SystemID should converge: init_err={initial_dist:.2f}, final_err={final_dist:.2f}"


# ── Full Engine Integration Tests ──────────────────────────────────────────────

class TestPhysiCoreEngine:
    def test_step_returns_correct_shapes(self, basic_engine, basic_cfg):
        state = np.zeros(basic_cfg.state_dim)
        x_ref = np.zeros(basic_cfg.state_dim)
        step  = basic_engine.step(state, x_ref)

        assert step.action.shape      == (basic_cfg.action_dim,)
        assert step.state_predicted.shape == (basic_cfg.state_dim,)
        assert step.residual.shape    == (basic_cfg.state_dim,)
        assert isinstance(step.uncertainty, float)
        assert step.loop_time_ms > 0

    def test_step_count_increments(self, basic_engine, basic_cfg):
        state = np.zeros(basic_cfg.state_dim)
        x_ref = np.zeros(basic_cfg.state_dim)
        for i in range(5):
            step = basic_engine.step(state, x_ref)
            assert step.step_count == i + 1

    def test_theorem1_state_stays_bounded(self, basic_cfg):
        """
        Theorem 1: State trajectory must remain in compact invariant region Ω.
        Test with a stable system and bounded disturbances.
        """
        Q = np.eye(4) * 10.0
        R = np.eye(2) * 1.0
        params = {"mass": 1.0, "friction": 0.2}
        bounds = (np.ones(2) * -2, np.ones(2) * 2)
        engine = PhysiCore(basic_cfg, simple_dynamics, params, Q, R, bounds)

        state = np.array([0.5, -0.3, 0.2, -0.1])
        x_ref = np.zeros(4)

        state_norms = []
        for _ in range(200):
            step = engine.step(state, x_ref)
            next_state = state + simple_dynamics(state, step.action, params) / 60.0
            next_state += np.random.randn(4) * 0.01   # bounded noise (A2)
            engine.observe(state, step.action, next_state)
            state = next_state
            state_norms.append(np.linalg.norm(state))

        max_norm = max(state_norms)
        # Should remain bounded (Theorem 1 guarantees compact invariant set)
        assert max_norm < 100.0, f"State unbounded: max norm = {max_norm:.2f}"

    def test_observe_accepts_real_transition(self, basic_engine, basic_cfg):
        state    = np.random.randn(basic_cfg.state_dim)
        x_ref    = np.zeros(basic_cfg.state_dim)
        step     = basic_engine.step(state, x_ref)
        next_s   = state + np.random.randn(basic_cfg.state_dim) * 0.01
        # Should not raise
        basic_engine.observe(state, step.action, next_s)

    def test_loop_time_within_budget(self, basic_cfg):
        """Verify 60 Hz budget (16.67 ms) is met on a basic system."""
        Q = np.eye(4); R = np.eye(2)
        params = {"mass": 1.0, "friction": 0.2}
        engine = PhysiCore(basic_cfg, simple_dynamics, params, Q, R)
        state  = np.zeros(4)
        x_ref  = np.zeros(4)

        times = []
        for _ in range(30):
            step = engine.step(state, x_ref)
            times.append(step.loop_time_ms)

        avg = np.mean(times)
        # On most machines this should be well under 16ms for a 4-dim system
        assert avg < 100.0, f"Average loop time {avg:.1f}ms too slow"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
