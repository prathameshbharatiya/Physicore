"""
PhysiCore — Hybrid Uncertainty-Aware Sim-to-Real Engine
========================================================
https://github.com/prathamesh-shirbhate/physicore
"""

from .core.engine import (
    PhysiCore,
    PhysiCoreConfig,
    ControlStep,
    PhysicsLayer,
    ResidualEnsemble,
    CEMOptimizer,
    OnlineSystemID,
)

__version__ = "1.0.0"
__author__  = "Prathamesh Shirbhate"
__all__ = [
    "PhysiCore",
    "PhysiCoreConfig",
    "ControlStep",
    "PhysicsLayer",
    "ResidualEnsemble",
    "CEMOptimizer",
    "OnlineSystemID",
]
