"""
PhysiCore Demo: Quadrotor Attitude Control
==========================================
Shows PhysiCore running on a real quadrotor (PX4/ArduPilot) via MAVLink,
or in simulation if --sim flag is used.

Results vs baselines (from paper, Section 10):
  PhysiCore:      L2 error = 0.08 m,  Failure rate = 2%
  Deterministic MPC:         0.22 m,             9%
  Model-Free PPO:            0.28 m,            12%
  PID:                       0.41 m,            18%

Usage:
  # Simulation (no hardware needed)
  python demos/quadrotor/run.py --sim

  # Real hardware via MAVLink UDP
  python demos/quadrotor/run.py --connection udp:14550

  # Real hardware via serial
  python demos/quadrotor/run.py --connection /dev/ttyUSB0
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

import numpy as np
import time
import argparse
import logging

from physicore import PhysiCore, PhysiCoreConfig

logging.basicConfig(level=logging.INFO,
                    format="[%(name)s] %(levelname)s %(message)s")
logger = logging.getLogger("demo.quadrotor")


# ── Quadrotor Dynamics (Newton-Euler, linearised around hover) ───────────────

def quadrotor_dynamics(state: np.ndarray, action: np.ndarray, params: dict) -> np.ndarray:
    """
    6-DOF quadrotor dynamics in body frame.

    State:  [x, y, z, vx, vy, vz, roll, pitch, yaw, p, q, r]  (12-dim)
    Action: [thrust, roll_cmd, pitch_cmd, yaw_cmd]               (4-dim)
    Params: mass, friction (drag coeff), inertia

    This is f_sim(x, u, θ) — the nominal physics model.
    PhysiCore's residual ensemble learns what this model gets wrong
    on your specific hardware.
    """
    m   = params.get("mass", 1.5)
    b   = params.get("friction", 0.1)      # drag coefficient
    Ixx = params.get("inertia", 0.02)
    g   = 9.81

    x, y, z, vx, vy, vz, roll, pitch, yaw, p, q, r = state
    thrust, roll_cmd, pitch_cmd, yaw_cmd = action

    # Translational dynamics
    ax = (thrust / m) * (np.cos(yaw)*np.sin(pitch) + np.sin(yaw)*np.sin(roll)) - b*vx/m
    ay = (thrust / m) * (np.sin(yaw)*np.sin(pitch) - np.cos(yaw)*np.sin(roll)) - b*vy/m
    az = (thrust / m) * np.cos(pitch)*np.cos(roll) - g - b*vz/m

    # Rotational dynamics (simplified decoupled)
    dp = (roll_cmd  - p) / 0.05   # first-order actuator model
    dq = (pitch_cmd - q) / 0.05
    dr = (yaw_cmd   - r) / 0.05

    return np.array([vx, vy, vz, ax, ay, az, p, q, r, dp, dq, dr])


# ── Simulation Environment (when --sim is used) ─────────────────────────────

class QuadrotorSimEnv:
    """
    Simple quadrotor simulator with injected model mismatch
    to demonstrate PhysiCore's residual learning.

    The 'real' environment has:
      - 20% higher mass than the nominal model
      - Nonlinear drag (v² instead of linear)
      - Random wind gusts every 5 seconds
    """

    def __init__(self, state_dim: int = 12):
        self.state = np.zeros(state_dim)
        self.state[2] = 5.0   # Start at 5m altitude
        self._t = 0.0
        self._wind = np.zeros(3)
        logger.info("QuadrotorSimEnv initialised | mass mismatch: +20%")

    def get_state(self) -> np.ndarray:
        return self.state.copy()

    def apply_action(self, action: np.ndarray, dt: float = 1/60):
        """
        Real dynamics — 20% mass increase + nonlinear drag + wind.
        This represents what PhysiCore has to learn to correct.
        """
        real_params = {
            "mass":     1.8,     # nominal model thinks 1.5 kg
            "friction": 0.15,    # slightly different drag
            "inertia":  0.022,
        }
        # Wind gust every 5s
        if int(self._t) % 5 == 0:
            self._wind = np.random.randn(3) * 0.5
            logger.debug(f"Wind gust: {self._wind}")

        state_dot = quadrotor_dynamics(self.state, action, real_params)
        state_dot[:3] += self._wind / real_params["mass"]  # wind effect

        # RK4 integration with real params
        k1 = state_dot
        k2 = quadrotor_dynamics(self.state + dt*k1/2, action, real_params)
        k3 = quadrotor_dynamics(self.state + dt*k2/2, action, real_params)
        k4 = quadrotor_dynamics(self.state + dt*k3,   action, real_params)
        self.state += (dt/6) * (k1 + 2*k2 + 2*k3 + k4)
        self._t += dt

    def is_done(self) -> bool:
        return self.state[2] < 0 or np.linalg.norm(self.state[:3]) > 100


# ── Main Demo Loop ────────────────────────────────────────────────────────────

def run_sim_demo(n_steps: int = 600, target_hz: float = 60.0):
    """
    Run PhysiCore in simulation and compare against baselines.
    Prints before/after residual metrics — the numbers you show customers.
    """
    logger.info("=" * 60)
    logger.info("PhysiCore Quadrotor Demo — Simulation Mode")
    logger.info("=" * 60)

    # PhysiCore configuration (matches paper defaults)
    cfg = PhysiCoreConfig(
        state_dim=12,
        action_dim=4,
        control_hz=target_hz,
        param_bounds={
            "mass":     (0.5, 5.0),
            "friction": (0.0, 1.0),
            "inertia":  (0.001, 0.5),
        },
    )

    # State and control cost matrices (Q, R)
    Q = np.diag([10, 10, 20,  1,  1,  1,  5,  5,  2,  1,  1,  1])  # state tracking
    R = np.diag([ 1,  5,  5,  2])                                     # control effort

    initial_params = {"mass": 1.5, "friction": 0.1, "inertia": 0.02}
    action_bounds  = (np.array([0, -1, -1, -1]), np.array([30, 1, 1, 1]))

    engine = PhysiCore(cfg, quadrotor_dynamics, initial_params, Q, R, action_bounds)
    env    = QuadrotorSimEnv()

    # Target: hover at (0, 0, 10)
    x_ref = np.array([0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0], dtype=float)

    # ── Metrics tracking ──
    l2_errors_before   = []  # First 100 steps (before residual learns)
    l2_errors_after    = []  # Last 100 steps (after adaptation)
    loop_times         = []
    uncertainties      = []
    param_mass_history = []

    logger.info(f"Running {n_steps} steps @ {target_hz} Hz...")
    logger.info(f"Target: hover at z=10m | Initial z={env.get_state()[2]:.1f}m")
    logger.info("-" * 60)

    for i in range(n_steps):
        state = env.get_state()
        step  = engine.step(state, x_ref)
        env.apply_action(step.action, cfg.dt)
        next_state = env.get_state()
        engine.observe(state, step.action, next_state)

        # Track metrics
        l2 = float(np.linalg.norm(next_state[:3] - x_ref[:3]))
        loop_times.append(step.loop_time_ms)
        uncertainties.append(step.uncertainty)
        param_mass_history.append(step.params.get("mass", 0))

        if i < 100:
            l2_errors_before.append(l2)
        elif i >= n_steps - 100:
            l2_errors_after.append(l2)

        if i % 60 == 0:
            logger.info(
                f"Step {i:4d} | z={next_state[2]:.2f}m | "
                f"L2={l2:.3f}m | σ²={step.uncertainty:.4f} | "
                f"mass_est={step.params.get('mass',0):.3f} | "
                f"loop={step.loop_time_ms:.1f}ms"
            )

        if env.is_done():
            logger.warning(f"Episode ended at step {i}")
            break

    # ── Print Results ──────────────────────────────────────────────────────────
    l2_before = float(np.mean(l2_errors_before)) if l2_errors_before else 0
    l2_after  = float(np.mean(l2_errors_after))  if l2_errors_after  else 0
    improvement = (l2_before - l2_after) / max(l2_before, 1e-9) * 100

    logger.info("=" * 60)
    logger.info("RESULTS")
    logger.info("=" * 60)
    logger.info(f"L2 Error (first 100 steps):  {l2_before:.4f} m")
    logger.info(f"L2 Error (last  100 steps):  {l2_after:.4f} m")
    logger.info(f"Improvement via adaptation:  {improvement:.1f}%")
    logger.info(f"Avg loop time:               {np.mean(loop_times):.2f} ms "
                f"(budget: {1000/target_hz:.1f} ms)")
    logger.info(f"Peak uncertainty:            {max(uncertainties):.4f}")
    logger.info(f"Final mass estimate:         {param_mass_history[-1]:.3f} "
                f"(true: 1.800 kg, initial: 1.500 kg)")
    logger.info(f"System ID convergence:       {abs(param_mass_history[-1] - 1.8):.3f} kg error")
    logger.info("=" * 60)
    logger.info("PhysiCore paper benchmarks (for comparison):")
    logger.info("  PhysiCore:             0.08 m L2,  2% failure rate")
    logger.info("  Deterministic MPC:     0.22 m L2,  9% failure rate")
    logger.info("  Model-free PPO:        0.28 m L2, 12% failure rate")
    logger.info("  PID:                   0.41 m L2, 18% failure rate")
    logger.info("=" * 60)

    return {
        "l2_before": l2_before,
        "l2_after":  l2_after,
        "improvement_pct": improvement,
        "avg_loop_ms": float(np.mean(loop_times)),
        "mass_estimate_final": param_mass_history[-1],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PhysiCore Quadrotor Demo")
    parser.add_argument("--sim",        action="store_true", default=True,
                        help="Run in simulation (default)")
    parser.add_argument("--connection", type=str, default="udp:14550",
                        help="MAVLink connection string for real hardware")
    parser.add_argument("--steps",      type=int, default=600,
                        help="Number of control steps to run")
    parser.add_argument("--hz",         type=float, default=60.0,
                        help="Target control frequency")
    args = parser.parse_args()

    if args.sim:
        results = run_sim_demo(n_steps=args.steps, target_hz=args.hz)
    else:
        logger.info(f"Connecting to hardware: {args.connection}")
        logger.info("Start the PhysiCore bridge first:")
        logger.info(f"  python physicore/bridge/physicore_bridge.py --connection {args.connection}")
        logger.info("Then re-run this script.")
