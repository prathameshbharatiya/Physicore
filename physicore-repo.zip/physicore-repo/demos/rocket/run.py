"""
PhysiCore Demo: Sounding Rocket Guidance (Based on PhysiCore Simulator)
=======================================================================
Demonstrates PhysiCore on rocket flight control — directly connected to
the physics engine in the PhysiCore web simulator (App.tsx).

Relevant for:
  - Stoke Space, Isar Aerospace, Orbex, HyImpulse
  - University rocketry teams (Purdue, SFU, UBC, UNSW)
  - ISRO, JAXA small launcher programs

Connects to PhysiCore bridge in 'rocket' mode for real hardware,
or runs standalone simulation using the same physics constants.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

import numpy as np
import logging
from physicore import PhysiCore, PhysiCoreConfig

logging.basicConfig(level=logging.INFO, format="[%(name)s] %(message)s")
logger = logging.getLogger("demo.rocket")

# Physical constants matching App.tsx
G      = 9.80665
R_AIR  = 287.05
L      = 0.0065
T0     = 288.15
P0     = 101325
RHO0   = 1.225


def atmospheric_density(altitude: float) -> float:
    if altitude < 0:
        return RHO0
    T = T0 - L * altitude
    if T <= 0:
        return 0.0
    P = P0 * ((1 - L * altitude / T0) ** (G / (R_AIR * L)))
    return P / (R_AIR * T)


def rocket_dynamics(state: np.ndarray, action: np.ndarray, params: dict) -> np.ndarray:
    """
    2D rocket dynamics (vertical + downrange).
    State:  [x, y, vx, vy, mass, angle]   (6-dim)
    Action: [thrust_magnitude, gimbal_angle] (2-dim)
    Params: cd, isp (learned by system ID from real flight data)
    """
    x, y, vx, vy, mass, angle = state
    thrust_mag, gimbal = action

    cd  = params.get("friction", 0.45)   # drag coefficient — 'friction' in PhysiCore
    isp = params.get("inertia", 220.0)   # specific impulse (s)
    dia = params.get("mass", 0.15)       # diameter (repurposed param slot)

    rho  = atmospheric_density(max(y, 0))
    area = np.pi * (dia / 2) ** 2
    v    = np.sqrt(vx**2 + vy**2)
    drag = 0.5 * rho * v**2 * cd * area

    # Thrust direction (gimbal from vertical)
    thrust_angle = angle + gimbal
    Ftx = thrust_mag * np.sin(thrust_angle)
    Fty = thrust_mag * np.cos(thrust_angle)

    # Drag (opposing velocity)
    Fdx = -drag * (vx / v) if v > 0.1 else 0.0
    Fdy = -drag * (vy / v) if v > 0.1 else 0.0

    # Gravity
    Fgy = -mass * G

    ax = (Ftx + Fdx) / mass
    ay = (Fty + Fdy + Fgy) / mass

    # Mass flow rate
    dm = -thrust_mag / (G * isp) if thrust_mag > 0 else 0.0

    return np.array([vx, vy, ax, ay, dm, 0.0])


def run_rocket_demo(burn_time: float = 8.0):
    """
    Guided rocket ascent with attitude control.
    Demonstrates how PhysiCore adapts to:
      - Cd uncertainty (aerodynamic model error)
      - ISP variation (motor performance spread)
      - Mass depletion tracking
    """
    cfg = PhysiCoreConfig(
        state_dim=6,
        action_dim=2,
        control_hz=20.0,           # Rocket guidance at 20 Hz
        param_bounds={
            "friction": (0.2, 0.8),   # Cd range
            "inertia":  (150, 280),   # ISP range (s)
            "mass":     (0.05, 0.30), # Diameter (m)
        },
        cem_samples=8,
        horizon=6,
    )

    Q = np.diag([1, 10, 0.5, 0.5, 0.1, 5])  # Penalise altitude and attitude errors
    R = np.diag([0.01, 1.0])                  # Thrust + gimbal cost

    initial_params = {"friction": 0.45, "inertia": 220.0, "mass": 0.15}
    action_bounds  = (np.array([0, -0.2]), np.array([500, 0.2]))

    engine = PhysiCore(cfg, rocket_dynamics, initial_params, Q, R, action_bounds)

    # Vertical ascent target
    x_ref = np.array([0, 3000, 0, 150, 0, 0], dtype=float)

    # Initial state: on the pad
    state = np.array([0.0, 0.0, 0.0, 0.0, 5.0, 0.02], dtype=float)

    logger.info(f"Rocket demo | dry_mass=1kg | prop_mass=5kg | burn_time={burn_time}s")

    altitudes    = []
    cd_estimates = []
    t = 0.0
    n_steps = int(burn_time * cfg.control_hz)

    for i in range(n_steps + int(5 * cfg.control_hz)):  # 5s coast after burnout
        # True parameters have 15% Cd error and 5% ISP error vs nominal
        true_params = {"friction": 0.52, "inertia": 209.0, "mass": 0.15}

        step = engine.step(state, x_ref)
        thrust_mag = step.action[0] if t < burn_time else 0.0
        action_real = np.array([thrust_mag, step.action[1]])

        # Real rocket response
        state_dot  = rocket_dynamics(state, action_real, true_params)
        next_state = state + state_dot * cfg.dt
        next_state[4] = max(next_state[4], 0.8)  # dry mass floor
        next_state[2] = max(next_state[1], 0)     # ground check

        engine.observe(state, action_real, next_state)
        state = next_state

        altitudes.append(state[1])
        cd_estimates.append(step.params.get("friction", 0))
        t += cfg.dt

        if i % int(cfg.control_hz) == 0:
            phase = "POWERED" if t < burn_time else "COAST"
            logger.info(f"t={t:.1f}s [{phase}] | alt={state[1]:.0f}m | "
                        f"v={state[3]:.1f}m/s | Cd_est={step.params['friction']:.3f}")

    max_alt = max(altitudes)
    cd_final = cd_estimates[-1]
    logger.info("=" * 50)
    logger.info(f"Max altitude: {max_alt:.0f} m")
    logger.info(f"Cd estimate: {cd_final:.3f} (true: 0.520)")
    logger.info(f"Cd error: {abs(cd_final - 0.52):.4f}")
    logger.info("=" * 50)


if __name__ == "__main__":
    run_rocket_demo()
